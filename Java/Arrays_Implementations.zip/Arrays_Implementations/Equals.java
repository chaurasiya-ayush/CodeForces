import java.util.Arrays;
public class Equals {
       public static void main(String[] args) {
        int [] a1 = {4,5,6,7,8,2,4 };
        int [] a2 = { 4,5,6,7,8,2,4};
        System.out.println(Arrays.equals(a1,a2)); 
        
    }
}
